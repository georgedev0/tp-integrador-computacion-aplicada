rm -rf /etc/.ssh /home/*/.ssh
dpkg -l | grep openssh
apt clean
dpkg -l | grep openssh
clear
apt purge -y openssh-client openssh-sftp-server
dpkg -purge $(dpkg -l | grep "openssh" | awk "{print $2}")
dpkg --purge $(dpkg -l | grep "openssh" | awk "{print $2}")
clear
dpkg -l | grep openssh
apt purge openssh-client
dpkg -l | grep openssh
clear
find /etc/ -type d -name *ssh*
su - matias
cat /etc/groups
cat /etc/group
clear
vi /bin/stamp.sh
chmod +x /bin/stamp.sh 
stamp
stamp.sh
vi /bin/stamp.sh
stamp.sh
vi /bin/stamp.sh
stamp.sh
cat /var/.stamp 
cat /var/.stamp 
reboot now
cat /var/.stamp 
nano /bin/stamp.sh 
vi /bin/stamp.sh 
stamp.sh
cat /var/.stamp 
mv /bin/stamp.sh /etc/.stamp.sh
clear
vi /etc/rc.local
ls /etc/rc.local
vi /etc/profile
chmod 777 /var/.stamp 
chmod 777 /etc/.stamp.sh 
reboot now
cat /var/.stamp 
date
shutdown
ls
cd archivos_tp/
ls
cd ..
ls -la
ls
cd archivos_tp/
ls
nano romero
vi romero
clear
ls -l romero
ps aux
clear
nano index.php
cat db.sql
clear
rm romero
ls
cat /etc/passwd
clear
lsblk
clear
systemctl status mariadb
systemctl status apache2
find / -type f -name os-release
find / -type f -name *.ser*
cat /opt/.servidorweb 
clear
shutdown now
clear
ls
cd archivos_tp/
ls
nano db.sql
vi db.sql
shutdown now
clear
cd archivos_tp/
vi db.sql 
vi archivos_tp/
cd archivos_tp/
ls
vi db.sql 
clear
vi db.sql 
clear
lsmod | grep
lsmod | grep vbox
VBoxControl --version
modprobe vboxsf
lsmod | grep vboxsf
apt install -y virtualbox-guest-utils virtualbox-gues-dkms
apt install -y virtualbox-guest-utils virtualbox-guest-dkms
vi db.sql 
vi db.sql 
vi db.sql 
vi db.sql 
ip a
cd /mnt/
ls
shutdown -r now
ls /mnt/
ls
cd /media/
ls
cd ..
cd /media/
ls
ls -l
cd cdrom0
ls
cd ..
cd ..
ls /media
shutdown -r now
cd /media/
ls
ls
cd ..
shutdown -r now
ls /mnt/
ls /media/
ls
clear
wget
wget http://192.168.0.6:8000/db2.sql -O /root/archivos_tp/db2.sql
wget http://192.168.0.6:8000/db2.sql -O /root/archivos_tp/db2.sql
wget http://192.168.0.6:8000/db2.sql -O /root/archivos_tp/db2.sql
wget http://192.168.0.6:8000/db2.sql -O /root/archivos_tp/db2.sql
wget http://192.168.0.6:8000/db2.sql -O /root/archivos_tp/db2.sql
ls
cd archivos_tp/
ls
mv db.sql db.original.sql
mv db2.sql db.sql
mariadb < db.sql 
vi index.php
vi index.php
cd /usr/bin/.videos/
ls
rm airbag.mp4 bcnr.mp4 boa.mp4 metallica.mp4 nirvana.mp4 omar_courtz.mp4 remera.mp4 rod_stewart.mp4 sabrina_carpenter.mp4 spinetta.mp4 tarea_fina.mp4 taylor_swift.mp4 
ls
cat /root/archivos_tp/db.sql 
clear
wget -r-nd -A.mp4 http://192.168.0.6:8000/
wget -r -nd -A.mp4 http://192.168.0.6:8000/
ls
ls -l
clear
cd
ls
cd archivos_tp/
ls
rm db.original.sql 
clear
shutdown now
clear
hostname
cat /etc/hostname
cat /etc/hosts
hostnamectl set-hostname TPServer
sed -i "s/devian/TPServer/" /etc/hosts
hostnamectl
clear
hostnamectl
cat /etc/hostname
cat /etc/hosts
clear
exec bash
scrit -a /root/tp_log.txt
script -a /root/tp_log.txt
poweroff
clear
script -a /root/tp_log.txt
clear
cat /etc/os-release
cat /etc/apt/sources.list
ls /etc/apt/sources.list.d/
df -h /
clear
ip a
ping -c 3 deb.debian.org
cat /etc/network/interfaces
sed -i "s/enp0s3/enp0s1/g" /etc/network/interfaces
cat /etc/network/interfaces
ifup enp0s1
clear
ip a
ping -c 3 deb.debian.org
clear
ls -la /root/archivos_tp/
apt update
clear
cp etc/apt/sources.list etc/apt/sources.list.bak
cp etc/apt/sources.list etc/apt/sources.list.bak
cp /etc/apt/sources.list /etc/apt/sources.list.bak
clear
ls /etc/apt
clear
nano etc/sources.list
nano /etc/sources.list
nano /etc/apt/sources.list
nano
apt install nano -y
loadkeys us
sed -i "s/cdn2-fastly.deb.debian.org/deb.debian.org/ /etc/apt/sources.list
sed -i "s/cdn2-fastly.deb.debian.org/deb.debian.org/ /etc/apt/sources.list"
sed -i "s/cdn2-fastly.deb.debian.org/deb.debian.org/" /etc/apt/sources.list
sed -i "3c deb http://security.debian.org/debian-security bullseye-security main contrib non-free" /etc/apt/sources.list
cat /etc/apt/sources.list
clear
cat /etc/apt/sources.list
clear
apt update
apt install nano -y
clear
cat /etc/apt/sources.list
apt update
CLEAR
clear
apt upgrade -y
clear
sed -i "s/bullseye/bookworm/g" /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
clear
apt full-upgrade -y
reboot
clear
script -a /root/tp_log.txt
cat /etc/os-release
cat /etc/debian-version
uname -r
clear
cat /etc/os-release
uname -r
cat /etc/debian-version
apt autoremove -y
nano --version
clear
poweroff
clear
script -a /root/tp_log.txt
nano /etc/ssh/sshd_config
clear
systemctl restart ssh
grep PermitRootLogin /etc/ssh/sshd_config
ip a
clear
shutdown
shutdown now
exit
sed -i "s/^PermitRootLogin yes/PermitRootLogin prohibit-password/" /etc/ssh/sshd_config
grep PermitRootLogin /etc/ssh/sshd_config
systemctl restart ssh
/exit
exit
clear
# punto 2.4
find / -name "*servidorweb*" 2>/dev/null
file /opt/.servidorweb 
ls -la /opt/.servidorweb 
cat /opt/.servidorweb 
apt update
apt install apache2 mariadb-server php libapache2-mod-php php-mysql -y
clear
systemctl is-active apache2 mariadb
systemctl is-enabled apache2 mariadb
php -v
clear
zgrep -l "CVE-2026-10961" /usr/share/doc/php8.2*/changelog.Debian.gz
clear
http://192.168.1.19
exit
find / -name "*servidorweb*" 2>/dev/null
find / -name "romero*" 2>/dev/null
find / -name "logo.png" 2>/dev/null
clear
script -a /root/tp_log.txt
exit
clear
exit
clear
# punto 2.5
grep -n -i -E "localhost|user|pass|dbname|logo" /root/archivos_tp/index.php
clear
cat /etc/apache2/mods-enabled/dir.conf
cp /root/archivos_tp/index.php /var/www/html/
mv /var/www/html/index.html /var/www/html/index.html.bak
ls -l /var/www/html
apache2ctl -M | grep php
clear
cat /root/archivos_tp/db.sql
clear
cat /root/archivos_tp/db.sql
clear
cat /root/archivos_tp/db.sql
clear
grep -i "create database" /root/archivos_tp/db.sql
exit
clear
script -a /root/tp_log.txt
exit
clear
poweroff
clear
mysql
clear
mysql
exit
clear
ls 
ls archivos_tp/
cat archivos_tp/db.sql 
clear
poweroff
ls
cat tp_log.txt 
clear
ls
cat archivos_tp/
ls archivos_tp/
poweroff
clear
clear
script -a /root/tp_log.txt
ip route
clear
nano /etc/network/interfaces
cat /etc/network/interfaces
clear
nano /etc/network/interfaces
clear
ip a
ip route
cat /etc/network/interfaces
clear
nano /etc/network/interfaces
clear
clear
sysctl net.ipv6.conf.all.disable_ipv6
tail -3 /etc/sysctl.conf
cat >> /etc/sysctl.conf << 'EOF'
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
EOF

sysctl -p
sysctl net.ipv6.conf.all.disable_ipv6
tail -3 /etc/sysctl.conf
reboot
clear
ip a
ip route
clear
head -1 /etc/network/interfaces
sed -i '1s/^# iface enp0s1 inet6 auto//' /etc/network/interfaces
nano /etc/network/interfaces
nano /etc/network/interfaces
ckear
head -1 /etc/network/interfaces
nano /etc/network/interfaces
clear
exit
clear
script -a /root/tp_log.txt
exit
clear
poweroff
poweroff
clear
clear
script -a /root/tp_log.txt
clear
lsblk
clear
mkdir /proc/particiones
cat /proc/partitions
clear
find / -iname "logo*" 2>/dev/null
exit
script -a /root/tp_log.txt
exit
clear
poweroff
clear
adduser estudiante
clear
mkdir /home/estudiante/.papelera_estudiante
chown estudiante:estudiante /home/estudiante/.papelera_estudiante
chmod 700 /home/estudiante/.papelera_estudiante
ls -la /home/estudiante
nano /home/estudiante/.bashrc
clear
su - estudiante
touch prueba.txt
ls
borrar prueba.txt
ls
ls -a .papelera_estudiante
exit
clear
nano /etc/cron.deny
clear
su - estudiante
clear
crontab -e
ls
clear
ls -la
clear
grep estudiante /etc/passwd
id estudiante
clear
cat /etc/.stamp.sh
grep -rl "stamp" /etc/profile /etc/profile.d/ /etc/bash.bashrc 2>/dev/null
ls -la /var/.stamp
find / -iname "*romero*" 2>/dev/null
ls -la /root/archivos_tp
grep -n -i "romero\|logo" /root/.bash_history
grep -rIli "romero" / --exclude-dir={proc,sys,dev,run} 2>/dev/null
clear
find / -iname "*zombie*" 2>/dev/null
sed -n '40,62p;144,157p' /root/.bash_history
clear
exit
clear
script -a /root/tp_log.txt
clear
ls
cat prueba.txt 
rm prueba.txt 
script -a /root/tp_log.txt
exit
clear
lsblk
clear
poweroff
clear
userdel -r estudiante
clear
script -a /root/tp_log.txt
poweroff
clear
ls -la /home/estudiante
tail -2 /home/estudiante/.bashrc
clear
grep "Accepted" /var/log/auth.log | tail -3
clear
grep -a "Accepted" /var/log/auth.log | tail -3
clear
   cat /etc/os-release
   uname -r
   cat /proc/sys/kernel/pid_max
   ulimit -u
   df -h -x tmpfs -x devtmpfs
clear
exi
poweroff
clear
script -a /root/tp_log.txt
clear
systemctl status ssh --no-pager
cleaar
clear
cat /root/archivos_tp/db.sql
clear
ls -la /home/estudiante
clear
tail -3 /home/estudiante/.bashrc
clear
su - estudiante
clear
crontab -l
clear
cat /etc/os-release
uname -r
cat /proc/sys/kernel/pid_max
ulimit -u
df -h -x tmpfs -x devtmpfs
clear
su - estudiante
clear
exit
ls
cd archivos_tp/
ls -la
find ñ-- -type f -name "romero"
cd 
ls
cat tp_log.txt 
x
clear
poweroff
