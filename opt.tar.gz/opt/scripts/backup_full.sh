#!/bin/bash
# backup_full.sh - comprime un directorio en un .tar.gz con la fecha en el nombre
# Uso: backup_full.sh <origen> <destino>

# Opcion de ayuda
if [ "$1" = "-help" ]; then
    echo "Uso: $0 <origen> <destino>"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "Genera: /backup_dir/log_bkp_AAAAMMDD.tar.gz"
    exit 0
fi

# Tienen que ser 2 argumentos
if [ $# -ne 2 ]; then
    echo "Error: cantidad de argumentos incorrecta. Use $0 -help"
    exit 1
fi

ORIGEN=$1
DESTINO=$2

# Validar que el origen exista
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el origen $ORIGEN no existe"
    exit 1
fi

# Validar que el destino sea una particion montada
if ! mountpoint -q "$DESTINO"; then
    echo "Error: el destino $DESTINO no esta montado"
    exit 1
fi

# Armar el nombre, por ejemplo log_bkp_20261112.tar.gz
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

# Comprimir
tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"
echo "Backup creado: $DESTINO/$ARCHIVO"
